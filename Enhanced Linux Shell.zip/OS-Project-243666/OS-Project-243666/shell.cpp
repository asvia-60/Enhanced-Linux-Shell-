#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

using namespace std;

#define MAX_HISTORY 10
#define MAX_INPUT 1024
#define MAX_ARGS 64
#define FIFO_PATH "/tmp/myfifo"

char* history[MAX_HISTORY];
int historyCount = 0;

// Function declarations
void displayPrompt();
void readInput(char* input);
int tokenize(char* input, int& bg, char*& inputFile, char*& outputFile, int& hasPipe, char* leftCmd[], char* rightCmd[], char* args[]);
void executeCommand(char* args[], int bg, char* inputFile, char* outputFile);
void executePipe(char* leftCmd[], char* rightCmd[], int bg);
void handleRedirection(char* args[], char* inputFile, char* outputFile);
void addToHistory(char* cmd);
void showHistory();
void createHardLink(char* source, char* target);
void createSoftLink(char* source, char* target);
void cleanup();

void displayPrompt() {
    cout << "bash> ";
    cout.flush();
}

void readInput(char* input) {
    cin.getline(input, MAX_INPUT);
}

int tokenize(char* input, int& bg, char*& inputFile, char*& outputFile, int& hasPipe, char* leftCmd[], char* rightCmd[], char* args[]) {
    bg = 0;
    hasPipe = 0;
    inputFile = nullptr;
    outputFile = nullptr;
    
    int argCount = 0;
    int leftCount = 0;
    int rightCount = 0;
    
    // Check for background execution
    int len = strlen(input);
    if (len > 0 && input[len-1] == '&') {
        bg = 1;
        input[len-1] = '\0';
        // Remove trailing spaces
        while (len-2 >= 0 && input[len-2] == ' ') {
            input[len-2] = '\0';
            len--;
        }
    }
    
    // Tokenize using strtok
    char* token = strtok(input, " ");
    int pipeFound = 0;
    
    while (token != nullptr) {
        if (strcmp(token, "|") == 0) {
            hasPipe = 1;
            pipeFound = 1;
            token = strtok(nullptr, " ");
            continue;
        }
        else if (strcmp(token, "<") == 0) {
            token = strtok(nullptr, " ");
            if (token) {
                inputFile = new char[strlen(token) + 1];
                strcpy(inputFile, token);
            }
        }
        else if (strcmp(token, ">") == 0) {
            token = strtok(nullptr, " ");
            if (token) {
                outputFile = new char[strlen(token) + 1];
                strcpy(outputFile, token);
            }
        }
        else {
            if (!pipeFound) {
                leftCmd[leftCount] = new char[strlen(token) + 1];
                strcpy(leftCmd[leftCount], token);
                leftCount++;
            } else {
                rightCmd[rightCount] = new char[strlen(token) + 1];
                strcpy(rightCmd[rightCount], token);
                rightCount++;
            }
            
            args[argCount] = new char[strlen(token) + 1];
            strcpy(args[argCount], token);
            argCount++;
        }
        
        token = strtok(nullptr, " ");
    }
    
    leftCmd[leftCount] = nullptr;
    rightCmd[rightCount] = nullptr;
    args[argCount] = nullptr;
    
    return argCount;
}

void handleRedirection(char* args[], char* inputFile, char* outputFile) {
    if (inputFile != nullptr) {
        int fd = open(inputFile, O_RDONLY);
        if (fd == -1) {
            perror("input file error");
            exit(1);
        }
        dup2(fd, STDIN_FILENO);
        close(fd);
    }
    
    if (outputFile != nullptr) {
        int fd = open(outputFile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd == -1) {
            perror("output file error");
            exit(1);
        }
        dup2(fd, STDOUT_FILENO);
        close(fd);
    }
    
    execvp(args[0], args);
    perror("execvp failed");
    exit(1);
}

void executePipe(char* leftCmd[], char* rightCmd[], int bg) {
    int fd[2];
    pid_t pid1, pid2;
    
    if (pipe(fd) == -1) {
        perror("pipe failed");
        return;
    }
    
    // First child - left command
    pid1 = fork();
    if (pid1 == 0) {
        dup2(fd[1], STDOUT_FILENO);
        close(fd[0]);
        close(fd[1]);
        execvp(leftCmd[0], leftCmd);
        perror("execvp failed");
        exit(1);
    }
    
    // Second child - right command
    pid2 = fork();
    if (pid2 == 0) {
        dup2(fd[0], STDIN_FILENO);
        close(fd[0]);
        close(fd[1]);
        execvp(rightCmd[0], rightCmd);
        perror("execvp failed");
        exit(1);
    }
    
    close(fd[0]);
    close(fd[1]);
    
    if (!bg) {
        waitpid(pid1, nullptr, 0);
        waitpid(pid2, nullptr, 0);
    }
}

void executeCommand(char* args[], int bg, char* inputFile, char* outputFile) {
    if (args[0] == nullptr) return;
    
    // Built-in commands
    if (strcmp(args[0], "exit") == 0) {
        cleanup();
        exit(0);
    }
    else if (strcmp(args[0], "history") == 0) {
        showHistory();
        return;
    }
    else if (strcmp(args[0], "!!") == 0) {
        if (historyCount > 0) {
            // Get the actual last command (not !!)
            char* lastCmd = history[historyCount - 1];
            
            // Don't add !! to history again
            // Just execute the last command directly
            
            cout << "Executing: " << lastCmd << endl;
            
            // Create a copy of the command
            char* cmdCopy = new char[strlen(lastCmd) + 1];
            strcpy(cmdCopy, lastCmd);
            
            // Parse the actual command
            int bg2, hasPipe2;
            char* inputFile2 = nullptr;
            char* outputFile2 = nullptr;
            char* leftCmd2[MAX_ARGS];
            char* rightCmd2[MAX_ARGS];
            char* args2[MAX_ARGS];
            
            tokenize(cmdCopy, bg2, inputFile2, outputFile2, hasPipe2, leftCmd2, rightCmd2, args2);
            
            // Execute the command based on whether it has pipe
            if (hasPipe2) {
                executePipe(leftCmd2, rightCmd2, bg2);
            } else {
                executeCommand(args2, bg2, inputFile2, outputFile2);
            }
            
            // Clean up
            delete[] cmdCopy;
            if (inputFile2) delete[] inputFile2;
            if (outputFile2) delete[] outputFile2;
            for (int i = 0; leftCmd2[i] != nullptr; i++) delete[] leftCmd2[i];
            for (int i = 0; rightCmd2[i] != nullptr; i++) delete[] rightCmd2[i];
            for (int i = 0; args2[i] != nullptr; i++) delete[] args2[i];
            
        } else {
            cout << "No commands in history" << endl;
        }
        return;
    }
    else if (strcmp(args[0], "link") == 0 && args[1] && args[2]) {
        createHardLink(args[1], args[2]);
        return;
    }
    else if (strcmp(args[0], "symlink") == 0 && args[1] && args[2]) {
        createSoftLink(args[1], args[2]);
        return;
    }
    
    // Normal command execution (rest of your existing code)
    pid_t pid = fork();
    
    if (pid == 0) {
        // Child process
        if (inputFile != nullptr || outputFile != nullptr) {
            handleRedirection(args, inputFile, outputFile);
        } else {
            execvp(args[0], args);
            perror("execvp failed");
            exit(1);
        }
    }
    else if (pid > 0) {
        if (!bg) {
            int status;
            waitpid(pid, &status, 0);
        } else {
            cout << "[Background process " << pid << "]" << endl;
        }
    }
    else {
        perror("fork failed");
    }
}

void addToHistory(char* cmd) {
    if (historyCount < MAX_HISTORY) {
        history[historyCount] = new char[strlen(cmd) + 1];
        strcpy(history[historyCount], cmd);
        historyCount++;
    } else {
        delete[] history[0];
        for (int i = 0; i < MAX_HISTORY - 1; i++) {
            history[i] = history[i+1];
        }
        history[MAX_HISTORY - 1] = new char[strlen(cmd) + 1];
        strcpy(history[MAX_HISTORY - 1], cmd);
    }
}

void showHistory() {
    for (int i = 0; i < historyCount; i++) {
        cout << (i + 1) << "  " << history[i] << endl;
    }
}

void createHardLink(char* source, char* target) {
    if (access(source, F_OK) == -1) {
        cout << "Error: Source file '" << source << "' does not exist" << endl;
        return;
    }
    if (access(target, F_OK) == 0) {
        cout << "Error: Target file '" << target << "' already exists" << endl;
        return;
    }
    
    if (link(source, target) == 0) {
        cout << "Hard link created: " << target << " -> " << source << endl;
    } else {
        perror("link failed");
    }
}

void createSoftLink(char* source, char* target) {
    if (symlink(source, target) == 0) {
        cout << "Symbolic link created: " << target << " -> " << source << endl;
    } else {
        perror("symlink failed");
    }
}

void cleanup() {
    unlink(FIFO_PATH);
    for (int i = 0; i < historyCount; i++) {
        delete[] history[i];
    }
}

int main() {
    cout << "Enhanced Shell with File and IPC Features" << endl;
    cout << "Type 'exit' to quit" << endl;
    cout << endl;
    
    signal(SIGCHLD, SIG_IGN); // Prevent zombie processes
    
    while (true) {
        displayPrompt();
        
        char input[MAX_INPUT];
        readInput(input);
        
        if (strlen(input) == 0) continue;
        
        addToHistory(input);
        
        int bg, hasPipe;
        char* inputFile = nullptr;
        char* outputFile = nullptr;
        char* leftCmd[MAX_ARGS];
        char* rightCmd[MAX_ARGS];
        char* args[MAX_ARGS];
        
        tokenize(input, bg, inputFile, outputFile, hasPipe, leftCmd, rightCmd, args);
        
        if (hasPipe) {
            executePipe(leftCmd, rightCmd, bg);
        } else {
            executeCommand(args, bg, inputFile, outputFile);
        }
        
        // Clean up dynamically allocated memory
        if (inputFile) delete[] inputFile;
        if (outputFile) delete[] outputFile;
        
        for (int i = 0; leftCmd[i] != nullptr; i++) delete[] leftCmd[i];
        for (int i = 0; rightCmd[i] != nullptr; i++) delete[] rightCmd[i];
        for (int i = 0; args[i] != nullptr; i++) delete[] args[i];
    }
    
    cleanup();
    return 0;
}
